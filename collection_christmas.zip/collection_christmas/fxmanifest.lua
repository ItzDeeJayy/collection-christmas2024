-- FX Information --
fx_version 'cerulean'
game 'gta5'
author 'DJ'
description 'Collection Christmas Decor'
version '1.0.1'
lua54 'yes'
this_is_a_map 'yes'

dependencies {
    '/server:4960',     -- ⚠️PLEASE READ⚠️; Requires at least SERVER build 4960.
}

data_file 'DLC_ITYP_REQUEST' 'stream/christmasdecor.ytyp'